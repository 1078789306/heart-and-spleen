seu_obj<-seu_obj_f
seu_obj<-readRDS("D:/2023.06.单细胞测序.心脾/心脾整体工作/心脾24h_zm1_zs10/0data/心脾合并24h筛选后_30038.rds")
remove(seu_obj_f)
seu_obj <- PercentageFeatureSet(seu_obj, pattern = "^mt-", col.name = "pMT")##线粒体计数
seu_obj <- PercentageFeatureSet(seu_obj, pattern = "^Hba|^Hbb", col.name = "pHB")##血红蛋白计数
seu_obj <- PercentageFeatureSet(seu_obj, pattern = "^Rps|^Rpl", col.name = "pRP")##核糖体计数
seu_obj <- SCTransform(seu_obj, verbose = T, vars.to.regress = c("nCount_RNA", "pMT"), conserve.memory = T)
seu_obj <- RunPCA(seu_obj,features = NULL,verbose = TRUE)

ElbowPlot(seu_obj, ndims = 50)
seu_obj <- RunUMAP(seu_obj, dims = 1:40, verbose = T)
seu_obj <- FindNeighbors(seu_obj, dims = 1:40)
DimPlot(seu_obj, reduction = "umap",label = T,raster=FALSE)
DimPlot(seu_obj, reduction = "umap",label = T,split.by = "orig.ident",raster=FALSE)
for (i in c(0.1,0.2, 0.3, 0.4, 0.5, 1, 2)) {
  seu_obj <- FindClusters(seu_obj, resolution = i)
  print(DimPlot(seu_obj, reduction = "umap") + labs(title = paste0("resolution: ", i))) }
table(seu_obj$orig.ident)
Idents(seu_obj) <- seu_obj$orig.ident
dim(seu_obj)
saveRDS(seu_obj,"D:/2023.06.单细胞测序.心脾/心脾整体工作/心脾24h_zm1_zs10/0data/心脾合并24h标准化后_30038.rds")



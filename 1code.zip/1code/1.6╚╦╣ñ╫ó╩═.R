library(Seurat)
library(dplyr)
library(reticulate)
library(sctransform)
library(cowplot)
library(ggplot2)
library(viridis)
library(tidyr)
library(magrittr)
library(reshape2)
library(readxl)
library(progeny)
library(readr)
library(stringr)
library(patchwork)
library(clustree)
library(clustree)
library(patchwork)
#######读入数据
xp_scdata<-total_xp
###对于数据添加心脏和脾脏分组
xp_scdata@meta.data$organism[xp_scdata@meta.data$orig.ident=='PZS10'|xp_scdata@meta.data$orig.ident=='PZM1']<-'Spleen'
xp_scdata@meta.data$organism[xp_scdata@meta.data$orig.ident=='XZS10'|xp_scdata@meta.data$orig.ident=='XZM1']<-'Heart'
DimPlot(xp_scdata, reduction = "umap", group.by = "organism", pt.size=0.5, label = TRUE, raster = F)

p1 <- DimPlot(xp_scdata, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)
p2 <- DimPlot(xp_scdata, reduction = "umap", group.by = "integrated_snn_res.0.1", pt.size=0.5, label = TRUE, raster = F)
p1 + p2 + plot_layout(widths = c(2,2))

##B cell:"Cd79a","Ly6d","Ms4a1"heart "Cd19","Fas","Igtp"spleen
celltype_marker<-c("Cd79a","Ly6d","Ms4a1","Cd19","Fas","Igtp","Cd80","Nt5e")
DefaultAssay(xp_scdata)<-"RNA"
Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1
DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
#####B细胞棋盘图，注释图，resolution0。4图合并
p1 <- DimPlot(xp_scdata, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)
p2 <- DimPlot(xp_scdata, reduction = "umap", group.by = "integrated_snn_res.0.1", pt.size=0.5, label = TRUE, raster = F)
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在0处B cell的marker高度表达所以将0定义为B细胞

##T cell:"Cd3d","Cd3e","Cd3g"heart "Cd4","Cd8"spleen  memoryT:
celltype_marker<-c("Cd3d","Cd3e","Cd3g","Lef1","Cd4","Igtp","Ccr7","Il7r","Tcf7","Klrg1")
DefaultAssay(xp_scdata)<-"RNA"
Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1
DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
#####T细胞棋盘图，注释图，resolution0。4图合并
p1 <- DimPlot(xp_scdata, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)
p2 <- DimPlot(xp_scdata, reduction = "umap", group.by = "integrated_snn_res.0.1", pt.size=0.5, label = TRUE, raster = F)
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在24\21\7处T cell的marker高度表达所以将这三处定义为T细胞

##Microglia cell:Cx3cr1  Macrophage:"Csf1r","Lyz1","Ctsc","C1qc","Trem2","Adgre1","Fcgr1","Maf","C1qb","Cd68","Itgam","Apex1","Asna1"
celltype_marker<-c("Cx3cr1","Csf1r","Lyz1","Ctsc","C1qc","Trem2","Adgre1","Fcgr1","Maf","C1qb","Cd68","Itgam","Apex1","Asna1","Cd163")
DefaultAssay(xp_scdata)<-"RNA"
Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1
DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
#####Microglia Macrophage细胞棋盘图，注释图，resolution0。4图合并
p1 <- DimPlot(xp_scdata, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)
p2 <- DimPlot(xp_scdata, reduction = "umap", group.by = "integrated_snn_res.0.1", pt.size=0.5, label = TRUE, raster = F)
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在1\3\14\17\23处巨噬细胞的marker高度表达所以将这五处定义为巨噬细胞

##Neutrophil:"Ly6g","Wfdc21","Cebpe"
celltype_marker<-c("Ly6g","Wfdc21","Cebpe")
DefaultAssay(xp_scdata)<-"RNA"
Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1
DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
#####Neutrophil细胞棋盘图，注释图，resolution0。4图合并
p1 <- DimPlot(xp_scdata, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)
p2 <- DimPlot(xp_scdata, reduction = "umap", group.by = "integrated_snn_res.0.1", pt.size=0.5, label = TRUE, raster = F)
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在1\3\14\17\23处巨噬细胞的marker高度表达所以将这五处定义为中性粒细胞

##Endothelial cell:"Cdh5","Nr2f2","Egfl7","Sox17","Stmn2","Tek","Epas1"
celltype_marker<-c("Cdh5","Nr2f2","Egfl7","Sox17","Stmn2","Tek","Epas1")
DefaultAssay(xp_scdata)<-"RNA"
Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1
DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
#####Endothelial细胞棋盘图，注释图，resolution0。4图合并
p1 <- DimPlot(xp_scdata, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)
p2 <- DimPlot(xp_scdata, reduction = "umap", group.by = "integrated_snn_res.0.1", pt.size=0.5, label = TRUE, raster = F)
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在10处内皮细胞的marker高度表达所以将这五处定义为内皮细胞


###Fibroblast："Fbln2","Fmod","Ckap4","Ddah1","Cthrc1","Ddr2"  Smooth muscle cell:"Mylk","Cnn1","Myh11","Myl9","Tagln","Srf"
celltype_marker<-c("Fbln2","Fmod","Ckap4","Ddah1","Cthrc1","Ddr2","Mylk","Cnn1","Myh11","Myl9","Tagln","Srf")
DefaultAssay(xp_scdata)<-"RNA"
Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1
DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
#####Fibroblast与Smooth muscle cell的细胞棋盘图，注释图，resolution0。4图合并
p1 <- DimPlot(xp_scdata, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)
p2 <- DimPlot(xp_scdata, reduction = "umap", group.by = "integrated_snn_res.0.1", pt.size=0.5, label = TRUE, raster = F)
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在19处上皮细胞的marker较平滑肌细胞高度表达所以将这五处定义为上皮细胞


###Monocyte:"Adipor1","App","Adcy7","Itgal","Chka","Cux1","Fxyd5","Igsf8","Il17ra","Trim8"
celltype_marker<-c("Adipor1","App","Adcy7","Itgal","Chka","Cux1","Fxyd5","Igsf8","Il17ra","Trim8")
DefaultAssay(xp_scdata)<-"RNA"
Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1
DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
#####单核细胞的细胞棋盘图，注释图，resolution0。4图合并
p1 <- DimPlot(xp_scdata, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)
p2 <- DimPlot(xp_scdata, reduction = "umap", group.by = "integrated_snn_res.0.1", pt.size=0.5, label = TRUE, raster = F)
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在13，14处单核细胞的marker高度表达所以将这五处定义为单核细胞

##NK:"Klrb1a","Klrk1","Klra7","Klra8","Klra9"
celltype_marker<-c("Klrb1a","Klrk1","Klra7","Klra8","Klra9")
DefaultAssay(xp_scdata)<-"RNA"
Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1
DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
#####NK细胞的细胞棋盘图，注释图，resolution0。4图合并
p1 <- DimPlot(xp_scdata, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)
p2 <- DimPlot(xp_scdata, reduction = "umap", group.by = "integrated_snn_res.0.1", pt.size=0.5, label = TRUE, raster = F)
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在12处NK细胞的marker高度表达所以将这五处定义为NK细胞

##Erythroid cell(红系细胞)："Tfrc","Ter119"
celltype_marker<-c("Tfrc","Ter119")
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在16处Erythroid cell的marker高表达，将16定义为Erythroid cell，结合聚类图与cellid注释图看，可以将11处也定义为Erythroid cell


####Cardiomyocytes（心肌细胞）:"Integrin alpha-1"	,"Integrin alpha-5"	,"Integrin alpha-6"	,"N-cadherin"	,"COLA1"	,"Acta1"	,"Actc1"	,"Actn2"	,"Alcam"	,"Atp2a2"	,"Cardiac troponin I"	,"Cav3"	,"cTnT"	,"Fabp3"	,"Gja1"	,"Gja5"	,"Hand2"	,"Mb"	,"Myh6"	,"Myl3"	,"Nkx2Ã¢â‚¬â€?"	,"Nppa"	,"Ryr2"	,"Scn5a"	,"SIRPa"	,"Tnnc1"	,"Tnni3"	,"Tnnt2"	,"Tpm"	,"Ttn"	,"VCAM-1"	,"VCAM1"	,"aActini"	,"Cs"	,"Hcn1"	,"Hcn4"	,"Myh7"	,"Pdk2"	,"Shox2"	,"Slc2a4"	,"Tbx5"
celltype_marker<-c("Integrin alpha-1"	,"Integrin alpha-5"	,"Integrin alpha-6"	,"N-cadherin"	,"COLA1"	,"Acta1"	,"Actc1"	,"Actn2"	,"Alcam"	,"Atp2a2"	,"Cardiac troponin I"	,"Cav3"	,"cTnT"	,"Fabp3"	,"Gja1"	,"Gja5"	,"Hand2"	,"Mb"	,"Myh6"	,"Myl3"	,"Nkx2Ã¢â‚¬â€?"	,"Nppa"	,"Ryr2"	,"Scn5a"	,"SIRPa"	,"Tnnc1"	,"Tnni3"	,"Tnnt2"	,"Tpm"	,"Ttn"	,"VCAM-1"	,"VCAM1"	,"aActini"	,"Cs"	,"Hcn1"	,"Hcn4"	,"Myh7"	,"Pdk2"	,"Shox2"	,"Slc2a4"	,"Tbx5")
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###心肌细胞暂时没有能够明确定义的类

##Dendritic cell(树突细胞)："Basp1"	,"Ccl5"	,"CD11c"	,"CD14"	,"CD16"	,"CD40"	,"Cd74"	,"CD80"	,"CD83"	,"CD86"	,"Fscn1"	,"H2-Aa"	,"H2-Ab1"	,"H2-Eb1"	,"Itgax"	,"S100a4"	,"Tcf7"	,"Cd11b"	,"Cd209a"	,"Flt3"	,"DC"	,"CD19"	,"CD3"	,"H2-DMb1"	,"Ly6G"	,"MHC class II"	,"NK1.1"	,"XCR1"
celltype_marker<-c("Basp1"	,"Ccl5"	,"CD11c"	,"CD14"	,"CD16"	,"CD40"	,"Cd74"	,"CD80"	,"CD83"	,"CD86"	,"Fscn1"	,"H2-Aa"	,"H2-Ab1"	,"H2-Eb1"	,"Itgax"	,"S100a4"	,"Tcf7"	,"Cd11b"	,"Cd209a"	,"Flt3"	,"DC"	,"CD19"	,"CD3"	,"H2-DMb1"	,"Ly6G"	,"MHC class II"	,"NK1.1"	,"XCR1")
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p3
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
###在第8亚群处高表达，所以将第8处第一位Dendritic cell

###Fibroblast(成纤维细胞) :"PDGFRa"	,"THY1"	,"Bgn"	,"Dcn"	,"Ecrg4"	,"Fn1"	,"Lcn2"	,"Prg4"	,"Spp1"	,"Timp1"	,"COLA1"	,"Acta2"	,"CD90.1"	,"CDH11"	,"Ckap4"	,"COL15A1"	,"Col1a1"	,"Col1a2"	,"COL3A1"	,"Comp"	,"Cthrc1"	,"cTnT"	,"Ctrc1"	,"Ddah1"	,"Ddr2"	,"Fbln2"	,"Fmod"	,"Fstl1"	,"GFP"	,"GPX3"	,"Gsn"	,"Lox"	,"LOXL1"	,"Mefsk-4"	,"Mmp2"	,"P4hb"	,"Pdgfr-a"	,"Pdgfra-GFP"	,"Pgp1"	,"Postn"	,"Ptn"	,"Sca1"	,"SPARC"	,"Spon2"	,"Tcf21"	,"VIM"	,"Cilp"	,"Ltbp2"	,"Tagln"
celltype_marker<-c("PDGFRa"	,"THY1"	,"Bgn"	,"Dcn"	,"Ecrg4"	,"Fn1"	,"Lcn2"	,"Prg4"	,"Spp1"	,"Timp1"	,"COLA1"	,"Acta2"	,"CD90.1"	,"CDH11"	,"Ckap4"	,"COL15A1"	,"Col1a1"	,"Col1a2"	,"COL3A1"	,"Comp"	,"Cthrc1"	,"cTnT"	,"Ctrc1"	,"Ddah1"	,"Ddr2"	,"Fbln2"	,"Fmod"	,"Fstl1"	,"GFP"	,"GPX3"	,"Gsn"	,"Lox"	,"LOXL1"	,"Mefsk-4"	,"Mmp2"	,"P4hb"	,"Pdgfr-a"	,"Pdgfra-GFP"	,"Pgp1"	,"Postn"	,"Ptn"	,"Sca1"	,"SPARC"	,"Spon2"	,"Tcf21"	,"VIM"	,"Cilp"	,"Ltbp2"	,"Tagln")
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p3
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))
##在第19处高表达，但第19处已经被定义为上皮细胞

###Plasmacytoid dendritic cell(浆状树突细胞)："Bst2"	,"Ly6d"	,"1810033B17Rik"	,"2310016M24Rik"	,"2410015M20Rik_sr104"	,"2810025M15Rik"	,"2900092E17Rik"	,"4732418C07Rik"	,"4930503E24Rik"	,"5430437P03Rik"	,"Acp5"	,"AI462493"	,"Aif1"	,"AK010403"	,"AK171153"	,"Akr1a4"	,"Alas1"	,"Ankrd13a"	,"Ano6"	,"Aprt"	,"Arhgef2"	,"Arl6ip4"	,"Atox1"	,"Atp2a3"	,"Atp5c1"	,"Atp5j2"	,"Atp5sl"	,"Atpif1"	,"Avpi1"	,"Bax"	,"BC049805"	,"BC096391_BC025067_Snora24"	,"Bpag1"	,"C1qa"	,"C1qc"	,"Caper"	,"Capns1"	,"Cd37"	,"Cd68"	,"Cd74"	,"Cdc42ep3"	,"Chchd3"	,"Ckb"	,"Coro1b"	,"Coro7"	,"Creb3"	,"Cstb"	,"D4Wsu53e"	,"Dnajb9"	,"Dok1"	,"Ehbp1l1"	,"Eif3f"	,"Eif4ebp1"	,"Elof1"	,"Exoc2"	,"F11r"	,"Fam173a"	,"Fam32a"	,"Fdx1l_Raver1"	,"Ftl1"	,"Fxc1_Tim9b"	,"Gltp"	,"Gm16517"	,"Gm5617"	,"Gngt2"	,"Gpx4"	,"Gusb"	,"H2-Aa"	,"H2-Ab1"	,"H2-Eb1"	,"Haao"	,"Haus8"	,"Hes1"	,"Hint1"	,"Hmgn1"	,"Hsd17b10"	,"Idh2"	,"Ifi30"	,"Il10rb"	,"Il12b"	,"Inpp4a"	,"Ip6k1"	,"Itgax"	,"Itm2b"	,"Khk"	,"Lamp1"	,"Lrp1"	,"Map1lc3b"	,"Mapk3"	,"Mcm6"	,"Mdh2"	,"Me2"	,"Mif"	,"Mir682"	,"Mrpl34"	,"Ms4a7"	,"Ncor1"	,"Ndufa10"	,"Ndufa9"	,"Ndufb8"	,"Neurl3"	,"Nt5c"	,"Nudt3"	,"P4hb"	,"Parp1"	,"Pip5k1c"	,"Pisd"	,"Pkn1"	,"Pkp3"	,"Plaur"	,"Plod3"	,"Plxnb2"	,"Plxnd1"	,"Ppp1r12c"	,"Pqlc1"	,"Prkcb"	,"Prkcd"	,"Psen2"	,"Psmc4"	,"Ptcd2"	,"Pycr2"	,"Qdpr"	,"Rasa3"	,"Rbbp7"	,"Rbm25"	,"Rcc2"	,"Rgs19"	,"Rinl"	,"Rogdi"	,"Rpl18"	,"Rplp0"	,"Rplp1"	,"Rps15"	,"Rps20"	,"Rps21"	,"Rps26"	,"Rps3"	,"Rps5"	,"Rps6"	,"Rxra"	,"Sae1"	,"Scamp4"	,"Senp6"	,"Sh3bp1"	,"Slc24a6"	,"Slc29a3"	,"Slc43a2"	,"Slc44a2"	,"Slc9a3r1"	,"Snord15a"	,"Snord38a"	,"Snrpd3"	,"Snrpf"	,"Sod1"	,"Spns3"	,"Srebf1"	,"Srp14"	,"Ssrp1"	,"Syf2"	,"Tcfeb"	,"Tmem176a"	,"Tmem176b"	,"Trp53_p53"	,"Tspan14"	,"Ube2j1"	,"Usp48"	,"Vac14"	,"Wbscr22"	,"Wdr89"	,"Ywhah"	,"Zbtb7a"	,"Zcchc24"	,"Zeb2"	,"CD287"	,"CD289"	,"CD317"	,"CD45R"	,"E2-2"	,"IRF8"	,"Siglec-H"
celltype_marker<-c("Bst2"	,"Ly6d"	,"1810033B17Rik"	,"2310016M24Rik"	,"2410015M20Rik_sr104"	,"2810025M15Rik"	,"2900092E17Rik"	,"4732418C07Rik"	,"4930503E24Rik"	,"5430437P03Rik"	,"Acp5"	,"AI462493"	,"Aif1"	,"AK010403"	,"AK171153"	,"Akr1a4"	,"Alas1"	,"Ankrd13a"	,"Ano6"	,"Aprt"	,"Arhgef2"	,"Arl6ip4"	,"Atox1"	,"Atp2a3"	,"Atp5c1"	,"Atp5j2"	,"Atp5sl"	,"Atpif1"	,"Avpi1"	,"Bax"	,"BC049805"	,"BC096391_BC025067_Snora24"	,"Bpag1"	,"C1qa"	,"C1qc"	,"Caper"	,"Capns1"	,"Cd37"	,"Cd68"	,"Cd74"	,"Cdc42ep3"	,"Chchd3"	,"Ckb"	,"Coro1b"	,"Coro7"	,"Creb3"	,"Cstb"	,"D4Wsu53e"	,"Dnajb9"	,"Dok1"	,"Ehbp1l1"	,"Eif3f"	,"Eif4ebp1"	,"Elof1"	,"Exoc2"	,"F11r"	,"Fam173a"	,"Fam32a"	,"Fdx1l_Raver1"	,"Ftl1"	,"Fxc1_Tim9b"	,"Gltp"	,"Gm16517"	,"Gm5617"	,"Gngt2"	,"Gpx4"	,"Gusb"	,"H2-Aa"	,"H2-Ab1"	,"H2-Eb1"	,"Haao"	,"Haus8"	,"Hes1"	,"Hint1"	,"Hmgn1"	,"Hsd17b10"	,"Idh2"	,"Ifi30"	,"Il10rb"	,"Il12b"	,"Inpp4a"	,"Ip6k1"	,"Itgax"	,"Itm2b"	,"Khk"	,"Lamp1"	,"Lrp1"	,"Map1lc3b"	,"Mapk3"	,"Mcm6"	,"Mdh2"	,"Me2"	,"Mif"	,"Mir682"	,"Mrpl34"	,"Ms4a7"	,"Ncor1"	,"Ndufa10"	,"Ndufa9"	,"Ndufb8"	,"Neurl3"	,"Nt5c"	,"Nudt3"	,"P4hb"	,"Parp1"	,"Pip5k1c"	,"Pisd"	,"Pkn1"	,"Pkp3"	,"Plaur"	,"Plod3"	,"Plxnb2"	,"Plxnd1"	,"Ppp1r12c"	,"Pqlc1"	,"Prkcb"	,"Prkcd"	,"Psen2"	,"Psmc4"	,"Ptcd2"	,"Pycr2"	,"Qdpr"	,"Rasa3"	,"Rbbp7"	,"Rbm25"	,"Rcc2"	,"Rgs19"	,"Rinl"	,"Rogdi"	,"Rpl18"	,"Rplp0"	,"Rplp1"	,"Rps15"	,"Rps20"	,"Rps21"	,"Rps26"	,"Rps3"	,"Rps5"	,"Rps6"	,"Rxra"	,"Sae1"	,"Scamp4"	,"Senp6"	,"Sh3bp1"	,"Slc24a6"	,"Slc29a3"	,"Slc43a2"	,"Slc44a2"	,"Slc9a3r1"	,"Snord15a"	,"Snord38a"	,"Snrpd3"	,"Snrpf"	,"Sod1"	,"Spns3"	,"Srebf1"	,"Srp14"	,"Ssrp1"	,"Syf2"	,"Tcfeb"	,"Tmem176a"	,"Tmem176b"	,"Trp53_p53"	,"Tspan14"	,"Ube2j1"	,"Usp48"	,"Vac14"	,"Wbscr22"	,"Wdr89"	,"Ywhah"	,"Zbtb7a"	,"Zcchc24"	,"Zeb2"	,"CD287"	,"CD289"	,"CD317"	,"CD45R"	,"E2-2"	,"IRF8"	,"Siglec-H")
p3<-DotPlot(xp_scdata, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p3
p1 + p2 +p3+ plot_layout(widths = c(1,1,1))

####现在将前面全部的marker基因收集一下
celltype_marker_all<-c("Cd79a","Ly6d","Ms4a1","Cd19","Fas","Igtp","Cd80","Nt5e","Cd3d","Cd3e","Cd3g","Lef1","Cd4","Igtp","Ccr7","Il7r","Tcf7","Klrg1","Cx3cr1","Csf1r","Lyz1","Ctsc","C1qc","Trem2","Adgre1","Fcgr1","Maf","C1qb","Cd68","Itgam","Apex1","Asna1"
                       ,"Ly6g","Wfdc21","Cebpe","Cdh5","Nr2f2","Egfl7","Sox17","Stmn2","Tek","Epas1","Fbln2","Fmod","Ckap4","Ddah1","Cthrc1","Ddr2","Mylk","Cnn1","Myh11","Myl9","Tagln","Srf","Adipor1","App","Adcy7","Itgal","Chka","Cux1","Fxyd5","Igsf8","Il17ra","Trim8"
                       ,"Klrb1a","Klrk1","Klra7","Klra8","Klra9","Tfrc","Ter119","Integrin alpha-1"	,"Integrin alpha-5"	,"Integrin alpha-6"	,"N-cadherin"	,"COLA1"	,"Acta1"	,"Actc1"	,"Actn2"	,"Alcam"	,"Atp2a2"	,"Cardiac troponin I"	,"Cav3"	,"cTnT"	,"Fabp3"	,"Gja1"	,"Gja5"	,"Hand2"	,"Mb"	,"Myh6"	,"Myl3"	,"Nkx2Ã¢â‚¬â€?"	,"Nppa"	,"Ryr2"	,"Scn5a"	,"SIRPa"	,"Tnnc1"	,"Tnni3"	,"Tnnt2"	,"Tpm"	,"Ttn"	,"VCAM-1"	,"VCAM1"	,"aActini"	,"Cs"	,"Hcn1"	,"Hcn4"	,"Myh7"	,"Pdk2"	,"Shox2"	,"Slc2a4"	,"Tbx5"
                       ,"Basp1"	,"Ccl5"	,"CD11c"	,"CD14"	,"CD16"	,"CD40"	,"Cd74"	,"CD80"	,"CD83"	,"CD86"	,"Fscn1"	,"H2-Aa"	,"H2-Ab1"	,"H2-Eb1"	,"Itgax"	,"S100a4"	,"Tcf7"	,"Cd11b"	,"Cd209a"	,"Flt3"	,"DC"	,"CD19"	,"CD3"	,"H2-DMb1"	,"Ly6G"	,"MHC class II"	,"NK1.1"	,"XCR1")
celltype_marker_all_1<-unique(celltype_marker_all)
Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1
p3<-DotPlot(xp_scdata, features = celltype_marker_all_1)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")
p3
#####注释结果

Idents(xp_scdata)<-xp_scdata$integrated_snn_res.0.1

annotation_curated_main <- read_excel("D:/2023.06.单细胞测序.心脾/心脾整体工作/心脾24h_zm1_zs10/0data/curated_annotation_mainV2.xlsx")


new_ids_main <- annotation_curated_main$main_cell_type
names(new_ids_main) <- levels(xp_scdata)
xp_scdata <- RenameIdents(xp_scdata, new_ids_main)
xp_scdata@meta.data$main_cell_type <- Idents(xp_scdata)
Idents(xp_scdata)<-xp_scdata$main_cell_type
DimPlot(xp_scdata, group.by = "main_cell_type",reduction = "umap", label = T, label.size = 5)

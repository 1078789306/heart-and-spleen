moncel<-readRDS("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\mar_mono_infla.rds")
Idents(moncel)<-moncel$orig.ident
table(moncel$celltype_first)
gc()
library(monocle)
library(dplyr)
library(Seurat)
library(patchwork)
library(tidyr)
##提取表型信息--细胞信息(建议载入细胞的聚类或者细胞类型鉴定信息、实验条件等信息)
celltype<-moncel$celltype_first
celltype<-as.data.frame(celltype)
celltype$cellname<-rownames(celltype)
celltype$sample<-substr(celltype$cellname,1,4)
celltype2<-unite(celltype,"cellnamenew",c("celltype","sample"), sep="-", remove = F)
moncel2<-moncel
moncel2$cellname<-celltype2$cellnamenew


expr_matrix <- as(as.matrix(moncel2@assays$RNA@counts), 'sparseMatrix')
##提取表型信息到p_data(phenotype_data)里面 
p_data <- moncel2@meta.data
#p_data$celltype <- pbmc@active.ident  ##整合每个细胞的细胞鉴定信息到p_data里面。如果已经添加则不必重复添加
f_data <- data.frame(gene_short_name = row.names(moncel2),row.names = row.names(moncel2))
##expr_matrix的行数与f_data的行数相同(gene number), expr_matrix的列数与p_data的行数相同(cell number)
#构建CDS对象(一定要确保identical(rownames(fd),rownames(expr_matrix))为TURE
gc()
pd <- new('AnnotatedDataFrame', data = p_data) 
fd <- new('AnnotatedDataFrame', data = f_data)
rownames(fd)
rownames(expr_matrix)
expr_matrix<- expr_matrix[rownames(fd), ]



identical(rownames(fd),rownames(expr_matrix))



#将p_data和f_data从data.frame转换AnnotatedDataFrame对象。
cds <- newCellDataSet(expr_matrix,
                      phenoData = pd,
                      featureData = fd,
                      lowerDetectionLimit = 0.5,
                      expressionFamily = negbinomial.size())

library(data.table)
cds <- estimateSizeFactors(cds)
cds <- estimateDispersions(cds)
cds <- detectGenes(cds, min_expr = 0.1)
dim(cds)
print(head(fData(cds)))#此时有13714个基因
expressed_genes <- row.names(subset(fData(cds),
                                    num_cells_expressed >= 10)) #过滤掉在小于10个细胞中表达的基因，还剩11095个基因。
#这一步输入的expressed_genes来自于步骤4。
#️️后续分析使用的是该方法
#也可输入seurat筛选出的高变基因：expressed_genes <- VariableFeatures(pbmc) 
####diff这一流程里面的fullModelFormulaStr后输入的应该是你自己的细胞分类或者注释结果

###########选择轨迹基因
##使用seurat选择的高变基因⚠️
express_genes <- VariableFeatures(total_mar_mono_infla)
cds <- setOrderingFilter(cds, express_genes)
plot_ordering_genes(cds)
##使用clusters差异表达基因（采用的这个方法）
Idents(moncel)<-moncel$celltype_first
deg.cluster <- FindAllMarkers(moncel)
express_genes <- subset(deg.cluster,p_val_adj<0.05)$gene
cds <- setOrderingFilter(cds, express_genes)
plot_ordering_genes(cds)
##使用monocle选择的高变基因⚠️
disp_table <- dispersionTable(cds)
disp.genes <- subset(disp_table, mean_expression >= 0.1 & dispersion_empirical >= 1 * dispersion_fit)$gene_id
cds <- setOrderingFilter(cds, disp.genes)
plot_ordering_genes(cds)


diff <- differentialGeneTest(cds[expressed_genes,],fullModelFormulaStr="~celltype_first",cores=1) 
#~后面是表示对谁做差异分析的变量，理论上可以为p_data的任意列名
head(diff)

##差异表达基因作为轨迹构建的基因,差异基因的选择标准是qval<0.01,decreasing=F表示按数值增加排序
deg <- subset(diff, qval < 0.01) #选出2829个基因
deg <- deg[order(deg$qval,decreasing=F),]
head(deg)

##差异基因的结果文件保存
write.table(deg,file="train.monocle.DEG.xlsx",col.names=T,row.names=F,sep="\t",quote=F)
DimPlot(moncel, reduction = "umap",group.by = "integrated_snn_res.0.1")
## 轨迹构建基因可视化
ordergene <- rownames(deg) 
cds <- setOrderingFilter(cds, ordergene)  
#这一步是很重要的，在我们得到想要的基因列表后，我们需要使用setOrderingFilter将它嵌入cds对象，后续的一系列操作都要依赖于这个list。
#setOrderingFilter之后，这些基因被储存在cds@featureData@data[["use_for_ordering"]]，可以通过table(cds@featureData@data[["use_for_ordering"]])查看
pdf("train.ordergenes.pdf")
plot_ordering_genes(cds)
dev.off()
#出的图黑色的点表示用来构建轨迹的差异基因，灰色表示背景基因。红色的线是根据第2步计算的基因表达大小和离散度分布的趋势(可以看到，找到的基因属于离散度比较高的基因
cds <- reduceDimension(cds, max_components = 2,
                       method = 'DDRTree')



cds <- orderCells(cds)
#️使用root_state参数可以设置拟时间轴的根，如下面的拟时间着色图中可以看出，左边是根。根据state图可以看出，根是State1，若要想把另一端设为根，可以按如下操作
cds <- orderCells(cds, root_state = 5) #把State5设成拟时间轴的起始点
pdf("train.monocle.pseudotime.pdf",width = 7,height = 7)
plot_cell_trajectory(cds,color_by="Pseudotime", size=1,show_backbone=TRUE) 
dev.off()
plot_cell_trajectory(cds,color_by="celltype_first", size=1,show_backbone=TRUE)
dev.off()



plot_cell_trajectory(cds, color_by = "organism",size=1,show_backbone=TRUE)
plot_cell_trajectory(cds, color_by = "State",size=1,show_backbone=TRUE)

#指定基因
s.genes <- c("Hif1a","Ccr7","Ccr2", "Lgals3")
p1 <- plot_genes_jitter(cds[s.genes,], grouping = "State", color_by = "State")
p2 <- plot_genes_violin(cds[s.genes,], grouping = "State", color_by = "State")
p3 <- plot_genes_in_pseudotime(cds[s.genes,], color_by = "State")
plotc <- p1|p2|p3
plotc
dev.off()

library(RColorBrewer)
display.brewer.all()
cols_1<-brewer.pal(8, 'Dark2')

plot_cell_trajectory(cds, color_by = 'celltype_first')+  
  scale_colour_manual(
    values = cols_1
    # aesthetics = c("colour", "fill")
  )

pdf("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\Fig19_monocel_cellname.pdf",width =10,height =5)
tmp1$ph_res
dev.off()

plot_cell_trajectory(cds, color_by = "State") + facet_wrap("~State", nrow = 1)
dev.off()

######基因热图
#这里是把排序基因（ordergene）提取出来做回归分析，来找它们是否跟拟时间有显著的关系
#如果不设置，就会用所有基因来做它们与拟时间的相关性
Time_diff <- differentialGeneTest(cds[ordergene,], cores = 1, 
                                  fullModelFormulaStr = "~sm.ns(Pseudotime)")
Time_diff <- Time_diff[,c(5,2,3,4,1,6,7)] #把gene放前面，也可以不改
write.csv(Time_diff, "Time_diff_all.csv", row.names = F)
Time_genes <- Time_diff %>% pull(gene_short_name) %>% as.character()
p=plot_pseudotime_heatmap(cds[Time_genes,], num_clusters=4, show_rownames=T, return_heatmap=T)
p
Time_genes <- top_n(Time_diff, n = 100, desc(qval)) %>% pull(gene_short_name) %>% as.character()
p = plot_pseudotime_heatmap(cds[Time_genes,], num_clusters=7, show_rownames=T, return_heatmap=T)
p
ggsave("Time_heatmapTop100.pdf", p, width = 5, height = 10)
ggsave("Time_heatmapAll.pdf", p, width = 5, height = 10)
gc()


BEAM_res=BEAM(cds,branch_point = 1,cores = 2)
#会返回每个基因的显著性，显著的基因就是那些随不同branch变化的基因
#这一步很慢
BEAM_res=BEAM_res[,c("gene_short_name","pval","qval")]
saveRDS(BEAM_res, file = "BEAM_res.rds")

BEAM_res_f<-subset(BEAM_res,subset=qval<1e-4)

BEAM_res_f_final<-top_n(BEAM_res_f,n=-170,qval)


tmp1=plot_genes_branched_heatmap(cds[row.names(BEAM_res_f_final),],
                                 branch_point = 1,
                                 num_clusters = 3, #这些基因被分成几个group
                                 cores = 2,
                                 branch_labels = c("Cell fate 1", "Cell fate 2"),
                                 hmcols = NULL, #默认,
                                 branch_colors = c("#979797", "#F05662", "#7990C8"), #pre-branch, Cell fate 1, Cell fate 2分别用什么颜色
                                 use_gene_short_name = T,
                                 show_rownames = T,
                                 return_heatmap = T #是否返回一些重要信息
)

pdf("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\Fig19_branched_heatmap_all.pdf",width =12,height = 18)
tmp1$ph_res
dev.off()
######提取基因
gene_group=tmp1$annotation_row
gene_group$gene=rownames(gene_group)

######基因轨迹
tset_genes<-c("Hif1a","Lgals3")
plot_genes_branched_pseudotime(cds[tset_genes,],
                               branch_point = 1,
                               color_by = "State",
                               ncol = 2)
gc()




#####富集分析

library(clusterProfiler)
library(org.Mm.eg.db)
allcluster_go=data.frame()
gene_group$gene<-rownames(gene_group)
for (i in unique(gene_group$Cluster)) {
  small_gene_group=filter(gene_group,gene_group$Cluster==i)
  df_name=bitr(small_gene_group$gene, fromType="SYMBOL", toType=c("ENTREZID"), OrgDb="org.Mm.eg.db")
  go <- enrichGO(gene         = unique(df_name$ENTREZID),
                 OrgDb         = org.Mm.eg.db,
                 keyType       = 'ENTREZID',
                 ont           = "BP",
                 pAdjustMethod = "BH",
                 pvalueCutoff  = 0.05,
                 qvalueCutoff  = 0.2,
                 readable      = TRUE)
  go_res=go@result
  if (dim(go_res)[1] != 0) {
    go_res$cluster=i
    allcluster_go=rbind(allcluster_go,go_res)
  }
}


write.csv(allcluster_go,"D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\心脾整体branchplot功能富集.csv")

head(allcluster_go[,c("ID","Description","qvalue","cluster")])

cluster2_go<-subset(allcluster_go,subset=cluster=="2")

cluster1_3_go<-subset(allcluster_go,subse=cluster=="1"|cluster=="3")

install.packages("C:/Users/Administrator/Desktop/monocle.tar(1).gz", repos = NULL, type="source")

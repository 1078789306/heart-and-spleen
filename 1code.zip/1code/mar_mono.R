library(Seurat)
library(dplyr)
library(reticulate)
library(sctransform)
library(cowplot)
library(ggplot2)
library(viridis)
library(tidyr)
library(magrittr)
library(reshape2)
library(readxl)
library(progeny)
library(readr)
library(stringr)
library(clustree)
library(patchwork)

total_MHeR<-readRDS("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\mar_momo_dc.rds")


total_mar_mono<-subset(total_MHeR,subset = c(main_cell_type=="macrophage"|main_cell_type=="Monocyte/Macrophage"|main_cell_type=="Monocyte"))

table(total_MHeR$main_cell_type)

total_mar_mono$organism
total_mar_mono@meta.data$SM[total_mar_mono@meta.data$orig.ident=='PZS10'|total_mar_mono@meta.data$orig.ident=='XZS10']<-'Sham'
total_mar_mono@meta.data$SM[total_mar_mono@meta.data$orig.ident=='PZM1'|total_mar_mono@meta.data$orig.ident=='XZM1']<-'Model'
DimPlot(total_mar_mono, reduction = "umap", group.by = "SM", pt.size=0.5, label = TRUE, raster = F)
FeaturePlot(total_mar_mono,features = "Hif1a",split.by = "SM")
DefaultAssay(total_mar_mono)<-"RNA"
Idents(total_mar_mono)<-total_mar_mono$SM
VlnPlot(total_mar_mono,features = "Hif1a",pt.size = 0,ncol = 1)

table(total_mar_mono$main_cell_type)


table(total_mar_mono$orig.ident)


mar_mon_matrix<-total_mar_mono@assays$RNA@counts

mar_mon_matrix<-as.matrix(mar_mon_matrix)
##使用CreateSeuratObject()函数创建Seurat对象，并在此处指定项目名称
seurat_obj_mar_mon <- CreateSeuratObject(counts = mar_mon_matrix,
                                         min.features = 200,
                                         min.cells = 3, 
                                         project = "mar_mon")


meta_mar_mon <- total_mar_mono@meta.data

#添加meta信息
seurat_obj_mar_mon <- AddMetaData(seurat_obj_mar_mon,metadata = meta_mar_mon)


seurat_obj_mar_mon <- PercentageFeatureSet(seurat_obj_mar_mon, pattern = "^mt-", col.name = "pMT")##线粒体计数

seurat_obj_mar_mon <- SCTransform(seurat_obj_mar_mon, verbose = T, vars.to.regress = c("nCount_RNA", "percent.mt"), conserve.memory = T)

remove(meta_mar_mon)



#######integrate合并数据的方式，一般在merge合并后不符合生物学时用该方式
split_seurat <- SplitObject(seurat_obj_mar_mon, split.by = "orig.ident")

# bm280k.list2=lapply(X = split_seurat, FUN = function(x) {
#   x <- PercentageFeatureSet(x, pattern = "^mt-",      col.name = "percent.mt")# 统计线粒体
#   x <- PercentageFeatureSet(x, pattern = "^Hba|^Hbb", col.name = "percent.HB")
#   x <- PercentageFeatureSet(x, pattern = "^Rps|^Rpl", col.name = "percent.RP")#核糖体
#   x <- subset(x, subset = nFeature_RNA > nFeature_lower & nFeature_RNA < nFeature_upper & 
#                 nCount_RNA > nCount_lower & nCount_RNA < nCount_upper & percent.mt < pMT_upper & percent.HB < pHB_upper)
#   x <- SCTransform(x,verbose = T)##标准化
# })

###去线粒体
options(future.globals.maxSize= 100000000000000)
total.features <- SelectIntegrationFeatures(object.list = split_seurat, nfeatures = 3000)
total.list <- PrepSCTIntegration(object.list = split_seurat, anchor.features = total.features,   verbose = FALSE)
#,reference =11 ，以第十一个个为参考，加快速度不影响结果（选取包含细胞最多的组作为reference）
total.anchors <- FindIntegrationAnchors(object.list = total.list, normalization.method = "SCT", anchor.features = total.features, reference = 2,verbose = FALSE)


total <- IntegrateData(anchorset = total.anchors, normalization.method = "SCT", verbose = FALSE)

total_mar_mono<-total
remove(total)
total_mar_mono <- RunPCA(total_mar_mono,features = NULL,verbose = TRUE)

ElbowPlot(total_mar_mono, ndims = 50)
total_mar_mono <- RunUMAP(total_mar_mono,dims = 1:50, verbose = T)
total_mar_mono <- FindNeighbors(total_mar_mono, dims = 1:50)

total_mar_mono <- RunTSNE(total_mar_mono, dims = 1:50, verbose = T)
DimPlot(total_mar_mono,reduction = "tsne")

for (i in c(0.1,0.2, 0.3, 0.4, 0.5, 1, 2)) {
  total_mar_mono <- FindClusters(total_mar_mono,resolution = i)
  print(DimPlot(total_mar_mono, reduction = "umap") + labs(title = paste0("resolution: ", i)))
}





#####resolution选择，选择resolution0.2作为后续分析
Idents(total_mar_mono)<-total_mar_mono$celltype_first

DimPlot(total_mar_mono,reduction = "tsne",split.by = "orig.ident",label = F)




DefaultAssay(total_mar_mono)<-"RNA"


mar_mono.markers <- FindAllMarkers(object =total_mar_mono, only.pos = TRUE, 
                                   min.pct = 0, 
                                   thresh.use = 0.25)
mar_mono.markers$filter<-substring(mar_mono.markers$gene,1,3)
mar_mono.markers_f<-subset(mar_mono.markers,subset = filter!="LOC")

markers_df = mar_mono.markers_f %>% group_by(cluster) %>% top_n(n = 20, wt = avg_log2FC)

DefaultAssay(total_mar_mono)<-"SCT"
DoHeatmap(total_mar_mono,features = markers_df$gene,label = F,slot ="scale.data")













DimPlot(total_mar_mono,reduction = "tsne",label = F)


celltype_marker_0.2<-c("Cd9","Ccl9","Prdx6","Ms4a4c","C1qa","C1qb","C1qc","Lyve1","Clec4e","Slfn4","Fpr1","Il1a","Chil3","Arg1","Cd14",
                       "Lilra5","Hspa1a","Cx3cr1","Cd72","Ccl5","P2ry6","Cd83","Cd79b","Tmem163","Cmah","Blk",
                       "Gimap6","S100a4","Irf4","Creld2","Ly6c2", "Fcmr","Tmem176b","Top2a","Wdfy4","Mki67",
                       "Plac8","Hp","Vcan","Gata2","Csf1","Itgal","Tpm1","Slc25a4","Ctsg","Ifitm1","Naaa","Plbd1"
)





celltype_marker<-c("Cd163","Cd68","C1qa","C1qb","C1qc","Cst3","Lyz","Cd14")

DefaultAssay(total_mar_mono)<-"RNA"
Idents(total_mar_mono)<-total_mar_mono$integrated_snn_res.0.2
DimPlot(total_mar_mono,reduction = "tsne",label = T)
p3<-DotPlot(total_mar_mono, features = celltype_marker_0.2)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")+scale_color_gradientn(colours = c("white",'dodgerblue','red'))+coord_flip()
p3

######修改图的样式
df<- p3$data
head(df)






ggplot(df, aes((x = factor(id,levels =c("0", "1", "3","6", "7", "2","4","10","5","9","8"))), y = features.plot)) +
  geom_point(aes(color = avg.exp.scaled, size = pct.exp)) +
  scale_color_gradientn(colors = c("white",'skyblue','red'), limits = c(-1.3, 2.5)) +
  labs(x = "", y = "")+
  theme_classic() 

ggsave("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_zm1_zs10\\心脾工作2024.2.6\\mar_mono\\dotplot.pdf",width = 8,height =10)

#####注释
###"Macrophages","MP","Macrophages","Macrophages","Macrophages","Monocyte","Macrophages","MP","Macrophages","Macrophages","Monocyte"
celltype_first<-c("Macrophages","Macrophages","MP","Macrophages","MP","Monocyte","Macrophages","Macrophages","Monocyte","Monocyte","MP")
names(celltype_first)<-levels(total_mar_mono)
total_mar_mono<-RenameIdents(total_mar_mono,celltype_first)
total_mar_mono@meta.data$celltype_first <- Idents(total_mar_mono)
Idents(total_mar_mono)<-total_mar_mono$celltype_first
DimPlot(total_mar_mono, reduction = "tsne",)

###挑选炎细胞亚型
infla_marker<-c("Hif1a","Ccr2","Ccl2","Lgals3","Slc2a1","Il1a")
Idents(total_mar_mono)<-total_mar_mono$integrated_snn_res.0.2
VlnPlot(total_mar_mono,features = infla_marker,pt.size = 0)

ggsave("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_zm1_zs10\\心脾工作2024.2.6\\mar_mono\\inflammatory_vlnplot.pdf",width = 15,height =6)

table(total_mar_mono$organism)
total_mar_mono_heart<-subset(total_mar_mono,subset =organism=="Heart" )

total_mar_mono_Spleen<-subset(total_mar_mono,subset =organism=="Spleen" )

FeaturePlot(total_mar_mono_Spleen,features = c("Hif1a","Ccr2"),reduction = "tsne",split.by = "SM")
Idents(total_mar_mono_heart)<-total_mar_mono_heart$SM
Idents(total_mar_mono_Spleen)<-total_mar_mono_Spleen$SM
########sham与model之间炎症基因表达差异
VlnPlot(total_mar_mono_heart
        ,features = c("Hif1a","Ccr2"),pt.size = 0)

total_mar_mono_count<-as.data.frame(t(as.data.frame(total_mar_mono_Spleen@assays$SCT@data)))
total_mar_mono_metadata<-total_mar_mono@meta.data
Hif1a<-as.data.frame(total_mar_mono_count$Hif1a)
Hif1a$cell<-rownames(total_mar_mono_count)
colnames(Hif1a)[1]<-"Hif1a_expression"
total_mar_mono_metadata$cell<-rownames(total_mar_mono_metadata)
metadata<-merge(Hif1a,total_mar_mono_metadata,by="cell")

library(ggsignif)


comparisons<-list(c("Sham","Model"))

p<-ggplot(metadata, aes(x = reorder(SM,Hif1a_expression),Hif1a_expression)) # x分组变量，y表达变量

p+geom_violin() #画出violin plot
p+geom_violin(aes(fill = SM))+#geom_boxplot(width = 0.15)+
  geom_signif(comparisons = comparisons,map_signif_level = T, textsize = 6, test = t.test, step_increase = 0.2) +
  guides(fill = "none") + xlab(NULL) + theme_classic()+ggtitle("mar_mono_spleen_Hif1a")+theme(axis.text.x = element_text(angle = 30,vjust = 0.85,hjust = 0.85))#按组别填充颜色



####细胞比例柱状图
Idents(total_mar_mono)<-total_mar_mono$celltype_first
Cellratio <- prop.table(table(Idents(total_mar_mono), total_mar_mono$orig.ident), margin = 2)#计算各组样本不同细胞群比例
Cellratio
Cellratio <- as.data.frame(Cellratio)
colourCount = length(unique(Cellratio$Var1))

######细胞比例柱状图
allcolour=c("skyblue","lightgreen","yellow","#FFA500")
library(ggplot2)
ggplot(Cellratio) + 
  geom_bar(aes(x =Var2, y= Freq, fill = Var1),stat = "identity",width = 0.7,size = 0.5,colour = '#222222')+ 
  theme_classic() +
  labs(x='Sample',y = 'Ratio')+
  scale_fill_manual(values = allcolour)+
  theme(panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"))









p1<-ggplot(Cellratio,aes(x=Var1,y=Freq,fill=Var2))+
  geom_bar(stat = 'identity', 
           #柱状图位置并排:
           position = 'dodge', #使用position=position_dodge(width=0.9),可使组内柱子间隔,自行试一下。
           width = 0.8,      #设置柱子宽度,使变量之间分开
           color='black')+labs(x=NULL)+ xlab(NULL)+ylab(NULL)+ theme(axis.text.x = element_text(angle = 45,vjust = 0.75,hjust = 0.75),panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))+guides(fill=guide_legend(title = "Celltype"))

p1+p2+plot_layout(widths = c(1,1),ncol = 1)

#####GO富集（BP）

#######通路富集
####对通路进行分析
####心脏sham/model
Idents(total_mar_mono_heart)<-total_mar_mono_heart$SM
table(total_mar_mono_Spleen$SM)

heart_marker<-FindMarkers(total_mar_mono_heart,ident.1 = "Model",ident.2 = "Sham",min.pct = 0.25)
heart_marker$p_val_adj

heart_marker_f<-subset(heart_marker,subset = abs(avg_log2FC)>0.25&p_val_adj<0.05)


heart_marker_up<-subset(heart_marker_f,subset = avg_log2FC>0)

heart_marker_down<-subset(heart_marker_f,subset=avg_log2FC<0)



library(clusterProfiler)
library(ggplot2)

ego_ALL_up <- enrichGO(gene = row.names(heart_marker_up), #universe = row.names(dge.celltype), 
                       OrgDb = 'org.Mm.eg.db', keyType = 'SYMBOL', ont = "BP", #设置为ALL时BP, CC, MF都计算 
                       pAdjustMethod = "BH", pvalueCutoff = 0.01, qvalueCutoff = 0.05)
ego_all_up <- data.frame(ego_ALL_up) 


ego_ALL_down <- enrichGO(gene = row.names(heart_marker_down), #universe = row.names(dge.celltype), 
                         OrgDb = 'org.Mm.eg.db', keyType = 'SYMBOL', ont = "BP", #设置为ALL时BP, CC, MF都计算 
                         pAdjustMethod = "BH", pvalueCutoff = 0.01, qvalueCutoff = 0.05)
ego_all_down <- data.frame(ego_ALL_down) 

barplot(ego_ALL_down)
barplot(ego_ALL_up)

barplot(ego_ALL_up, split="ONTOLOGY")+facet_grid(ONTOLOGY~., scale="free")#柱状图


write.csv(ego_all_up,"D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\heart_sham_model_up_GO.csv")

write.csv(ego_all_down,"D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\heart_sham_model_down_GO.csv")


######spleen

Idents(total_mar_mono_Spleen)<-total_mar_mono_Spleen$SM
spleen_marker<-FindMarkers(total_mar_mono_Spleen,ident.1 = "Model",ident.2 = "Sham",min.pct = 0.25)
heart_marker$p_val_adj

spleen_marker_f<-subset(spleen_marker,subset = abs(avg_log2FC)>0.25&p_val_adj<0.05)


spleen_marker_up<-subset(spleen_marker_f,subset = avg_log2FC>0)

spleen_marker_down<-subset(spleen_marker_f,subset=avg_log2FC<0)



library(clusterProfiler)
library(ggplot2)

ego_ALL_up <- enrichGO(gene = row.names(spleen_marker_up), #universe = row.names(dge.celltype), 
                       OrgDb = 'org.Mm.eg.db', keyType = 'SYMBOL', ont = "BP", #设置为ALL时BP, CC, MF都计算 
                       pAdjustMethod = "BH", pvalueCutoff = 0.01, qvalueCutoff = 0.05)
ego_all_up <- data.frame(ego_ALL_up) 


ego_ALL_down <- enrichGO(gene = row.names(spleen_marker_down), #universe = row.names(dge.celltype), 
                         OrgDb = 'org.Mm.eg.db', keyType = 'SYMBOL', ont = "BP", #设置为ALL时BP, CC, MF都计算 
                         pAdjustMethod = "BH", pvalueCutoff = 0.01, qvalueCutoff = 0.05)
ego_all_down <- data.frame(ego_ALL_down) 



write.csv(ego_all_up,"D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\spleen_sham_model_up_GO.csv")

write.csv(ego_all_down,"D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\spleen_sham_model_down_GO.csv")







#######实验验证的marker可视化
library(RColorBrewer)
proinflam_cellmarker<-c("Hif1a","Ccr2","Ccr5","Cxcr2")

Warburg_cellmarker<-c("Slc2a1","Slc2a4","Pdk1","Ldah")
total_mar_mono$organism
total_heart<-subset(total_mar_mono,subset=organism=="Heart")
total_spleen<-subset(total_mar_mono,subset=organism=="Spleen")


p1<-FeaturePlot(total_heart,reduction = "tsne",features = proinflam_cellmarker,split.by = "SM",pt.size = 1.2,ncol = 2)



p3<-FeaturePlot(total_spleen,reduction = "tsne",features = proinflam_cellmarker,split.by = "SM",pt.size = 1.2,ncol = 2)


p1
ggsave("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\Fig14_spleen_inflammation_model_sham_featureplot.pdf",width = 10,height = 20)
Idents(total_mar_mono)<-total_mar_mono$orig.ident

VlnPlot(total_mar_mono,features = Warburg_cellmarker,pt.size = 0,ncol = 2)
setwd("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\")
ggsave(p3,file="Fig10_inflam_cellmarker_featureplot_sham_model.pdf",width =10,height = 20)
#####进一步对巨噬细胞和单核细胞进行细化（寻找炎性基因和迁徙相关的巨噬细胞）
###炎性打分（GSEA数据库中炎性通路，采用addmouculescore进行打分）
Idents(total_mar_mono)<-total_mar_mono$integrated_snn_res.0.2
total_mar_mono <- RunTSNE(total_mar_mono, dims = 1:40, verbose = T)
DimPlot(total_mar_mono,reduction = "tsne")
DefaultAssay(total_mar_mono) <- "RNA"
cd_features <- read.csv("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_zm1_zs10\\0data\\炎症基因集合小鼠.csv")

cd_features<-cd_features[,-1]



gene<-as.list(cd_features)
DefaultAssay(total_mar_mono)
total_mar_mono <- AddModuleScore(total_mar_mono,
                                 features = gene,
                                 ctrl = 100,
                                 name = "infla_Features")
colnames(total_mar_mono@meta.data)
colnames(total_mar_mono@meta.data)[21] <- 'Inflammatory_Score' 

library(ggplot2)
mydata<- FetchData(total_mar_mono,vars = c("UMAP_1","UMAP_2","Inflammatory_Score"))
a <- ggplot(mydata,aes(x = UMAP_1,y =UMAP_2,colour = Inflammatory_Score))+geom_point(size = 1)+scale_color_gradientn(values = seq(0,1,0.2),colours = c('blue','cyan','green','yellow','orange','red'))

a+ theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                      panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))


VlnPlot(total_mar_mono,features = 'Inflammatory_Score' )



total_mar_mono[["stage"]] <- ifelse(total_mar_mono@meta.data[,"Inflammatory_Score"] > mean(total_mar_mono@meta.data[,"Inflammatory_Score"]),"High","Low")
rownames(pbmc@meta.data)

Idents(total_mar_mono) <- 'stage'
total_mar_mono$main_cell_type
DimPlot(total_mar_mono,reduction = "tsne",label = T)


Idents(total_mar_mono)<-total_mar_mono$integrated_snn_res.0.2


DefaultAssay(total_mar_mono)<-"RNA"

celltype_marker<-c("Hif1a","Ccr2","Ccr7","Ccr5","Cxcr1","Cxcr2")
FeaturePlot(total_mar_mono,features = "Cxcr2",reduction = "tsne",split.by = "SM")


ggsave("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\Fig9_Cxcr2_featureplot.pdf",width = 10,height = 5)

VlnPlot(total_mar_mono,features = celltype_marker,ncol = 3,pt.size = 0)


cellmarker<-c("Ccr2","H2-Eb1","H2-DMb1","H2-DMa","Cxcl3","Il1a","Lgals3","Slc2a1","Ly6a","Ccl2","Ccl5","Ccl3","Hif1a")
VlnPlot(total_mar_mono,features = cellmarker,ncol = 3,pt.size = 0)
p3<-DotPlot(total_mar_mono, features = cellmarker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")+scale_color_gradientn(colours = c("white",'dodgerblue','red'))
p3

Idents(total_mar_mono)<-total_mar_mono$integrated_snn_res.0.2
DimPlot(total_mar_mono,split.by = "organism",reduction = "tsne")
total_mar_mono_infla<-subset(total_mar_mono,subset=c(integrated_snn_res.0.2=="0"|integrated_snn_res.0.2=="1"|integrated_snn_res.0.2=="3"|integrated_snn_res.0.2=="6"|integrated_snn_res.0.2=="7"|integrated_snn_res.0.2=="8"|integrated_snn_res.0.2=="9"))
saveRDS(total_mar_mono_infla,"D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\mar_mono_infla.rds")

#####单细胞gsva

library(ggplot2)
library(dplyr)
library(msigdbr)
library(Seurat)
library(GSVA)
library(pheatmap)
library(patchwork)
library(msigdbr) #提供MSigdb数据库基因集

mar_mono_matrix <- as.matrix(total_mar_mono@assays$RNA@counts)#提取count矩阵
total_mar_mono$orig.ident
meta <- total_mar_mono@meta.data[,c("orig.ident", "integrated_snn_res.0.4")]#分组信息，为了后续作图

msigdbr_species() #可以看到，这个包涵盖了20个物种

mouse<-msigdbr(species = "Mus musculus")
mouse[1:5,1:5]
table(human$gs_cat)

table(human$gs_subcat)
###GO通路获取
mouse_GO_bp = msigdbr(species = "Mus musculus",
                      category = "C5", #GO在C5
                      subcategory = "GO:BP") %>% 
  dplyr::select(gs_name,gene_symbol)#这里可以选择gene symbol，也可以选择ID，根据自己数据需求来，主要为了方便
mouse_GO_bp_Set = mouse_GO_bp %>% split(x = .$gene_symbol, f = .$gs_name)#后续gsva要求是list，所以将他转化为list

####hallmarker通路获取

human_HALL = msigdbr(species = "Homo sapiens",
                     category = "H" #GO在C5
) %>% 
  dplyr::select(gs_name,gene_symbol)#这里可以选择gene symbol，也可以选择ID，根据自己数据需求来，主要为了方便
human_HALL_Set = human_HALL %>% split(x = .$gene_symbol, f = .$gs_name)#后续gsva要求是list，所以将他转化为list



#####对每个细胞亚型取均值
Idents(total_mar_mono) <-total_mar_mono$orig.ident
expr <- AverageExpression(total_mar_mono,assays = "SCT",slot = "data")[[1]]
#选取非零基因
expr<- expr[rowSums(expr)>0,]
expr <- as.matrix(expr)
head(expr)

mar_mono_gsva <- gsva(expr = expr, 
                      gset.idx.list = mouse_GO_bp_Set,method="gsva",min.sz>1)                                                           


gsva.df <- data.frame(Genesets=rownames(mar_mono_gsva), mar_mono_gsva, check.names = F) 
write.csv(gsva.df, "D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\gsva_res.csv", row.names = F) 
pheatmap::pheatmap(mar_mono_gsva, show_colnames = T, scale = "row",angle_col = "45", 
                   color = colorRampPalette(c("navy", "white", "firebrick3"))(50))

###GSEA

library(clusterProfiler)
library(enrichplot)
library(org.Mm.eg.db)
#为每个基因添加对应的ENTREZID
spleen_marker_f$gene <- rownames(spleen_marker_f)
ids=bitr(spleen_marker_f$gene,'SYMBOL','ENTREZID','org.Mm.eg.db')
#合并数据，cluser3.markers中没有ENTREZID的基因将被过虑掉
spleen.markers=merge(spleen_marker_f,ids,by.x='gene',by.y='SYMBOL')

#将基因按照avg_log2FC的大小进行降序排列
spleen.markers <- spleen.markers[order(spleen.markers$avg_log2FC,decreasing = T),]
#生成仅含有ENTREZID名字和avg_log2FC值的gene list
spleen.markers_list <- as.numeric(spleen.markers$avg_log2FC)
names(spleen.markers_list) <- spleen.markers$ENTREZID
head(spleen.markers_list)
####

spleen_gsego <- gseGO(spleen.markers_list,OrgDb="org.Mm.eg.db",pvalueCutoff = 0.05)
head(spleen_gsego)
#将富集结果按照NES绝对值降序排列
spleen_gsego_arrange <- arrange(spleen_gsego,desc(abs(NES)))

spleen_gsego_reslut<-spleen_gsego_arrange@result

# 显示top20信号通路

top10_up<-spleen_gsego_reslut%>% filter(p.adjust < 0.008) %>%filter(NES>0)%>% head(n= 10)

top10_down<-spleen_gsego_reslut%>% filter(p.adjust < 0.008) %>%filter(NES<0)%>% head(n= 10)


write.csv(top10_up,"D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\gsea_tpo10_up.csv")
write.csv(top10_down,"D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\gsea_tpo10_down.csv")
write.csv(spleen_gsego_reslut,"D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\gsea_go_all.csv")

spleen_GSEA<-read.csv("D:\\2023.06.单细胞测序.心脾\\心脾整体工作\\心脾24h_ZM1_ZS10.9.21\\补充图\\spleen_GSEA_all.csv")

spleen_GSEA$Description
ggplot(spleen_GSEA, aes(reorder(Description, NES), NES))  +geom_col(aes(fill= factor(group,levels =c("up", "down"))))+
  coord_flip() +
  labs(x="Pathway", y="Normalized Enrichment Score",
       title="GO_BP pathways NES from GSEA") +
  theme_minimal() ####以7.5进行绘图填


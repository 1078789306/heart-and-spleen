library(Seurat)
library(dplyr)
library(reticulate)
library(sctransform)
library(cowplot)
library(ggplot2)
library(viridis)
library(tidyr)
library(magrittr)
library(reshape2)
library(readxl)
library(progeny)
library(readr)
library(stringr)
library(patchwork)
library(clustree)
library(clustree)
library(patchwork)

####将mar_mon_dc的矩阵提取出来
seurat_obj_recluster<-subset(xp_scdata,subset=main_cell_type=='Macrophage/DC/Monocyte')
sham<-subset(seurat_obj_recluster,subset = SM=="Sham")
model<-subset(seurat_obj_recluster,subset = SM=="Model")
table(sham$organism)
table(model$organism)
table(seurat_obj_recluster$organism)
table(seurat_obj_recluster$SM)
mar_mon_dc_matrix<-seurat_obj_recluster@assays$RNA@counts



gc()


mar_mon_dc_matrix<-as.matrix(mar_mon_dc_matrix)
##使用CreateSeuratObject()函数创建Seurat对象，并在此处指定项目名称
seurat_obj_mar_mon_dc <- CreateSeuratObject(counts = mar_mon_dc_matrix,
                                     min.features = 200,
                                     min.cells = 3, 
                                     project = "mar_mon_dc")


meta_mar_mon_dc <- seurat_obj_recluster@meta.data

#添加meta信息
mar_mon_dc_FILTER <- AddMetaData(seurat_obj_mar_mon_dc,metadata = meta_mar_mon_dc)


seurat_obj_mar_mon_dc <- PercentageFeatureSet(mar_mon_dc_FILTER, pattern = "^mt-", col.name = "pMT")##线粒体计数

metadata<-seurat_obj_mar_mon_dc@meta.data
seurat_obj_mar_mon_dc <- SCTransform(seurat_obj_mar_mon_dc, verbose = T, vars.to.regress = c("nCount_RNA", "pMT"), conserve.memory = T)





#######integrate合并数据的方式，一般在merge合并后不符合生物学时用该方式
split_seurat <- SplitObject(seurat_obj_mar_mon_dc, split.by = "orig.ident")

###去线粒体
options(future.globals.maxSize= 100000000000000)
gc()
total.features <- SelectIntegrationFeatures(object.list = split_seurat, nfeatures = 3000)
total.list <- PrepSCTIntegration(object.list = split_seurat, anchor.features = total.features,   verbose = FALSE)
#,reference =11 ，以第十一个个为参考，加快速度不影响结果（选取包含细胞最多的组作为reference）
total.anchors <- FindIntegrationAnchors(object.list = total.list, normalization.method = "SCT", anchor.features = total.features, reference = 2,verbose = FALSE)


total <- IntegrateData(anchorset = total.anchors, normalization.method = "SCT", verbose = FALSE)


table(total$orig.ident)
remove(split_seurat)
total_MHeR=total
remove(total)
total_MHeR <- RunPCA(total_MHeR)
ElbowPlot(total_MHeR, ndims = 50)
total_MHeR <- RunUMAP(total_MHeR, dims = 1:50, verbose = T)
total_MHeR <- RunTSNE(total_MHeR, dims = 1:50, verbose = T)
total_MHeR <- FindNeighbors(total_MHeR, dims = 1:50)
DimPlot(total_MHeR, reduction = "tsne" ,group.by = "orig.ident",label=T,raster=FALSE)

total_MHeR$orig.ident
for (i in c(0.1,0.2, 0.3, 0.4, 0.5, 1, 2)) {
  total_MHeR<- FindClusters(total_MHeR, resolution = i)
  print(DimPlot(total_MHeR, reduction = "tsne") + labs(title = paste0("resolution: ", i))) }



xp.markers <- FindAllMarkers(object =total_MHeR, only.pos = TRUE, 
                              min.pct = 0.25, 
                              thresh.use = 0.25)
xp.markers$filter<-substring(xp.markers$gene,1,3)
xp.markers_f<-subset(xp.markers,subset = filter!="LOC")

markers_df = xp.markers_f %>% group_by(cluster) %>% top_n(n = 50, wt = avg_log2FC)

DefaultAssay(total_MHeR)<-"SCT"
DoHeatmap(total_MHeR,features = markers_df$gene,label = F,slot = "scale.data")



celltype_marker_0.3<-c("Arg1","Lgals3","Cd9","Ccl9","Prdx6","Ms4a4c","C1qa","C1qb","C1qc","Lyve1","Mmp9","Il1a","Chil3","Clec4e","Slfn4","Fpr1","Cmah","Cd83","Cd79b","Blk","Fcmr","Tmem163","Bank1","Irf4","Creld2","Ly6c2","Hp","Plac8","Top2a","Wdfy4","Mki67","Irf8","Ms4a4b","Ccl5","Gimap6","Itgal","Tpm1","Slc25a4","Myl3","H2-Ab1","H2-Eb1","Cd209a","Flt3","Tcf4","Siglech","Ccr9","Klk1")


DefaultAssay(total_MHeR)<-"RNA"
Idents(total_MHeR)<-total_MHeR$integrated_snn_res.0.2
DimPlot(total_MHeR,reduction = "tsne")
p3<-DotPlot(total_MHeR, features = celltype_marker_0.3)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")+scale_color_gradientn(colours = c("white",'dodgerblue','red'))+coord_flip()
p3


df<- p3$data
head(df)





ggplot(df, aes((x = factor(id,levels =c("0", "1","3","8","5", "4", "7","6","10","2","9"))), y = features.plot)) +
  geom_point(aes(color = avg.exp.scaled, size = pct.exp)) +
  scale_color_gradientn(colors = c("white",'skyblue','red'), limits = c(-1.3, 2.5)) +
  labs(x = "", y = "")+
  theme_classic() 


#####注释
Idents(total_MHeR)<-total_MHeR$integrated_snn_res.0.2

annotation_curated_main <- read_excel("D:/2023.06.单细胞测序.心脾/心脾整体工作/心脾24h_zm1_zs10/心脾工作2024.2.6/mar_mono_dc/curated_annotation_mainmar_mono_dc.xlsx")


new_ids_main <- annotation_curated_main$main_cell_type
names(new_ids_main) <- levels(total_MHeR)
total_MHeR <- RenameIdents(total_MHeR, new_ids_main)
total_MHeR@meta.data$main_cell_type <- Idents(total_MHeR)
Idents(total_MHeR)<-total_MHeR$main_cell_type
DimPlot(total_MHeR, group.by = "main_cell_type",reduction = "tsne", label = F, label.size = 5)

DefaultAssay(total_MHeR)<-"RNA"
Idents(total_MHeR)<-total_MHeR$integrated_snn_res.0.2






###pro/anti
celltype_marker<-c("Il1rn","Il10","Il4","Il11","Tgfb1","Tnfrs1a","Tnfrs1b","Il1r2","Il18bp","Il1b","Tnf","Ccl12","Ccl5","Ccl17","Ccl22")

####M1/M2
celltype_marker<-c("Tnf","Il6","Il1b","Nos2","Cxcl10","Cd86","Il1a","Ccl5","Ccr7","Arg1","Arg2","Il10","Pdcd1lg2","Cd274","Csf1r","Il1rn","Il1r2","Il4ra","Lyve1","Ccl4","Ccl2","Ccl20","Ccl17","Ccl22","Vegfa","Vegfb","Vegfc","Egf","Ctsa","Ctsb","Ctsd","Tgfb1","Tgfb2","Tgfb3","Mmp14","Mmp19","Mmp9")








DotPlot(total_MHeR, features = celltype_marker)+RotatedAxis()+
  scale_x_discrete("")+scale_y_discrete("")+scale_color_gradientn(colours = c("white",'dodgerblue','red'))
####GO分析
library(clusterProfiler)
library(ggplot2)
install.packages("org.Mm.eg.db")
BiocManager::install("org.Mm.eg.db")
library(org.Mm.eg.db)
group <- data.frame(gene=xp.markers_f$gene,
                    group=xp.markers_f$cluster)

Gene_ID <- bitr(xp.markers_f$gene, fromType="SYMBOL", 
                toType="ENTREZID", 
                OrgDb="org.Mm.eg.db")

#构建文件并分析
data  <- merge(Gene_ID,group,by.x='SYMBOL',by.y='gene')
#####go富集
data_GO <- compareCluster(
  ENTREZID~group, 
  data=data, 
  fun="enrichGO", 
  OrgDb="org.Mm.eg.db",
  ont = "BP",
  pAdjustMethod = "BH",
  pvalueCutoff = 0.05,
  qvalueCutoff = 0.05
)

data_GO_sim <- simplify(data_GO, 
                        cutoff=0.7, 
                        by="p.adjust", 
                        select_fun=min)


dotplot(data_GO_sim, showCategory=10,font.size = 4)
data_GO_sim_fil <- data_GO_sim@compareClusterResult

#####重新绘制
table(total_MHeR2$orig.ident)
df_GO <- data_GO_sim_fil
library(forcats)
df_GO$Description <- as.factor(df_GO$Description)
df_GO$Description <- fct_inorder(df_GO$Description)

df_GO_f= df_GO %>% group_by(Cluster) %>% top_n(n = 10, wt = pvalue)

ggplot(df_GO_f, aes(Cluster, Description)) +
  geom_point(aes(fill=p.adjust, size=Count), shape=21)+
  theme_bw()+
  theme(axis.text.x=element_text(angle=90,hjust = 1,vjust=0.5),
        axis.text = element_text(color = 'black', size = 10))+
  scale_fill_gradient(low="purple",high="yellow")+
  labs(x=NULL,y=NULL)+coord_flip()

######细胞比例柱状图

table(total_MHeR$main_cell_type)
Idents(total_MHeR)<-total_MHeR$orig.ident
Cellratio <- prop.table(table(Idents(total_MHeR), total_MHeR$main_cell_type), margin = 2)#计算各组样本不同细胞群比例
Cellratio
Cellratio <- as.data.frame(Cellratio)
write.csv(celltype,"D:/2023.06.单细胞测序.心脾/心脾24样本细胞比例径向柱状图/celltpye_numer.csv")




data_heart<-read.csv("D:\\2023.06.单细胞测序.心脾\\心脾细胞比例2023.8.23\\heart总.csv")

p<-ggplot(data_heart,aes(x=as.factor(celltype),y=ratio))+geom_bar(stat="identity",fill="blue")
p
p+coord_polar()
p+ylim(-2,3.5)+coord_polar()


df1<-data.frame(individual=paste("Mister",seq(1,60),sep=""),
                value=rep(c(sample(60:100,9,replace=T),NA),6))
df1$id<-seq(1,nrow(df1))
df1
df1$angle<-df$angle1
df1$hjust<-df$hjust
df1
df1$fill<-c(rep("A",10),rep("B",10),rep("C",10),rep("D",10),rep("E",10),rep("F",10))


# 构造唯一标识，用作 x 轴，并按该顺序绘制
data$id = 1:nrow(data)
# 添加显示文本的角度
angle <- 90 - 360 * (data$id - 0.5) / nrow(data)

data_heart$fill<-c(rep("B cell",4),rep("Dendritic cell",4),rep("Macrophages",4),rep("Monocytes",4),rep("Neutrophils",4),rep("NK cell",4),rep("T cell",4))
ggplot(data_heart,aes(x=as.factor(celltype),y=ratio))+geom_bar(stat="identity",aes(fill=fill))+coord_polar()+ylim(-2,4)+geom_text(aes(x=celltype,y=ratio+0.5,label=ratio),size=3,alpha=0.6,angle = ifelse(angle < -90, angle+180, angle))+theme_minimal()+ylab("")+xlab("")+theme(axis.text.y = element_blank())#+theme(axis.text.y = element_blank(),axis.ticks.y = element_blank(),axis.text.x = element_blank(),panel.grid = element_blank(),legend.position="none")+scale_fill_manual(values=c("red","yellow","blue","green","orange","skyblue","purple"))

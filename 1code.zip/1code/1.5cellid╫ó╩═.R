library(CelliD)
gc()

total_xp<-readRDS("D:/2023.06.单细胞测序.心脾/心脾整体工作/心脾24h_zm1_zs10/0data/心脏integrate合并_umap降维数据.rds")
total_xp<-RunMCA(total_xp)

##test2根据test1中的结果进行进一步的筛选，除去样本中不应该有的或者注释结果较少的细胞（这一步大概要重复3-5次才能注释出较好的结果）
panglao <- read_tsv("https://panglaodb.se/markers/PanglaoDB_markers_27_Mar_2020.tsv.gz")

#根据物种过滤，数据就是小鼠的
panglao_pancreas <- panglao %>%  dplyr::filter(str_detect(species,"Mm"))

#######根据注释结果去除不应该有的细胞
panglao_pancreas <- panglao %>%  dplyr::filter(str_detect(species,"Mm"))


panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Alveolar macrophages")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Basophils")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Distal tubule cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Hepatic stellate cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Kupffer cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Loop of Henle cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Megakaryocytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Microfold cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Megakaryocytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Pancreatic stellate cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Enterocytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Müller cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Adipocyte progenitor cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "B cells naive")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Erythroblasts")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Hematopoietic stem cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Mast cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "T regulatory cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Ependymal cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Purkinje neurons")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Adipocytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Embryonic stem cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Alpha cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Astrocytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Cajal-Retzius cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Chondrocytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Endothelial cells (aorta)")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Epithelial cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Germ cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Glomus cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Interneurons")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Mesangial cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Interneurons")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Myoepithelial cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Natural killer T cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Nuocytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Osteoclasts")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Pericytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Plasma cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Platelets")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "T helper cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Bergmann glia")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Enteroendocrine cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Hepatocytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Immature neurons")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Luminal epithelial cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Peritubular myoid cells")

panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Beta cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "B cells memory")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Basal cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Cardiomyocytes")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Enteric neurons")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Gamma delta T cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Luteal cells")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Microglia")
panglao_pancreas <- panglao_pancreas %>% filter(`cell type`!= "Podocytes")












panglao_pancreas <- panglao_pancreas %>%  
  dplyr::group_by(`cell type`) %>%  
  dplyr::summarise(geneset = list(`official gene symbol`))
pancreas_gs <- setNames(panglao_pancreas$geneset, panglao_pancreas$`cell type`)

#富集分析，用的超几何检验
# ngenes = sapply(Hallmark, function(x) sum(x %in% rownames(pbmc_small)))
pancreas_gs  = lapply(pancreas_gs, function(i){ return(  intersect(stringr::str_to_title(i), rownames(total_xp))  )} )
pancreas_gs=pancreas_gs[sapply(pancreas_gs,function(x) length(x) > 1 )]


HGT_pancreas_gs <- RunCellHGT(total_xp, pathways = pancreas_gs, dims = 1:30, n.features = 200,log.trans=T) #每个细胞选200个特征基因
HGT_pancreas_gs[1:4,1:4]
#矩阵的每一列依次：判断是否是最大值，得到一列布尔值，结合矩阵的行名会返回行名中的一个元素（也就是最有可能的细胞类型）。
#所有列运行完了之后会得到所有细胞最可能的注释
pancreas_gs_prediction <- rownames(HGT_pancreas_gs)[apply(HGT_pancreas_gs, 2, which.max)]
pancreas_gs_prediction
#pancreas_gs_prediction_signif <- ifelse(apply(HGT_pancreas_gs, 2, max)>2, yes = pancreas_gs_prediction, "unassigned")
#pancreas_gs_prediction_signif<-as.matrix(pancreas_gs_prediction_signif)
#Baron$pancreas_gs_prediction <- pancreas_gs_prediction_signif
total_xp$pancreas_gs_prediction <- pancreas_gs_prediction
head(Baron@meta.data,2)

Idents(Baron) <- Baron@meta.data$integrated_snn_res.0.5
p6<-DimPlot(total_xp, reduction = "umap", group.by = "pancreas_gs_prediction", pt.size=0.5, label = TRUE, raster = F)

p6
table(total_xp$pancreas_gs_prediction)
#####保存图片
celltype_cellmarker_jpg = paste0("Fig6.xp_cellmarker_celltype_",ProjectNames,".jpg")
jpeg(celltype_cellmarker_jpg,width=10,height=5,res=350,units="in")
print(p6)
dev.off()
celltype_cellmarker_pdf = paste0("5.xp_","cellmarker_","celltype",".pdf")
pdf(celltype_cellmarker_pdf,width=10,height=5)
print(p6)
dev.off()
saveRDS(total_xp,"D:/2023.06.单细胞测序.心脾/心脾24样本2023.7.2/0data/心脾注释完成24.rds")
seu_obj_xp<-readRDS("D:/2023.06.单细胞测序.心脾/心脾整体工作/心脾24h_zm1_zs10/0data/心脾合并24h标准化后_30038.rds")
table(seu_obj_xp$orig.ident)
options(future.globals.maxSize= 100000000000000)

#######integrate合并数据的方式，一般在merge合并后不符合生物学时用该方式
split_seurat <- SplitObject(seu_obj_xp, split.by = "orig.ident")
remove(seu_obj_xp)
# bm280k.list2=lapply(X = split_seurat, FUN = function(x) {
#   x <- PercentageFeatureSet(x, pattern = "^mt-",      col.name = "percent.mt")# 统计线粒体
#   x <- PercentageFeatureSet(x, pattern = "^Hba|^Hbb", col.name = "percent.HB")
#   x <- PercentageFeatureSet(x, pattern = "^Rps|^Rpl", col.name = "percent.RP")#核糖体
#   x <- subset(x, subset = nFeature_RNA > nFeature_lower & nFeature_RNA < nFeature_upper & 
#                 nCount_RNA > nCount_lower & nCount_RNA < nCount_upper & percent.mt < pMT_upper & percent.HB < pHB_upper)
#   x <- SCTransform(x,verbose = T)##标准化
# })

###去线粒体

total.features <- SelectIntegrationFeatures(object.list = split_seurat, nfeatures = 5000)
total.list <- PrepSCTIntegration(object.list = split_seurat, anchor.features = total.features,   verbose = FALSE)
#,reference =11 ，以第十一个个为参考，加快速度不影响结果（选取包含细胞最多的组作为reference）
total.anchors <- FindIntegrationAnchors(object.list = total.list, normalization.method = "SCT", anchor.features = total.features, verbose = FALSE,reference = 2)


total <- IntegrateData(anchorset = total.anchors, normalization.method = "SCT", verbose = FALSE)
dim(total)
table(seu_objx$orig.ident)
table(total$orig.ident)
remove(split_seurat)
total_MHeR=total
total_MHeR <- RunPCA(total_MHeR)
ElbowPlot(total_MHeR, ndims = 50)
total_MHeR <- RunUMAP(total_MHeR, dims = 1:40, verbose = T)
total_MHeR <- FindNeighbors(total_MHeR, dims = 1:40)
p1<-DimPlot(total_MHeR, reduction = "umap",split.by = "orig.ident" ,label=T,raster=FALSE)
p1
DimPlot(total_MHeR, reduction = "umap" ,label=T,raster=FALSE)
total_MHeR$orig.ident
total_MHeR <- RunTSNE(total_MHeR, dims = 1:30, verbose = T)
p2<-DimPlot(total_MHeR, reduction = "tsne",split.by = "orig.ident" ,label=T,,raster=FALSE)
DimPlot(total_MHeR, reduction = "tsne" ,label=T,,raster=FALSE)
p1 + p2 + plot_layout(widths = c(2, 2))


for (i in c(0.1,0.2, 0.3, 0.4, 0.5,0.6,0.7,0.8,0.9, 1, 2)) {
  total_MHeR <- FindClusters(total_MHeR,resolution = i)
  print(DimPlot(total_MHeR, reduction = "umap") + labs(title = paste0("resolution: ", i)))
}
saveRDS(total,'D:/2023.06.单细胞测序.心脾/心脏integrate合并.rds')
saveRDS(total_MHeR,'D:/2023.06.单细胞测序.心脾/心脾整体工作/心脾24h_zm1_zs10/0data/心脏integrate合并_umap降维数据.rds')
total_MHeR<-readRDS('D:/2023.06.单细胞测序.心脾/心脏integrate合并_umap降维数据.rds')
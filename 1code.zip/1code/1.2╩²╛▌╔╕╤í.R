#####读入心脏脾脏数据
seu_obj<-readRDS("D:/2023.06.单细胞测序.心脾/心脾整体工作/心脾24h_zm1_zs10/0data/心脾合并24h_34490.rds")
#####线粒体数目计算
seu_obj[["percent.mt"]] <- PercentageFeatureSet(seu_obj, pattern = "^mt-")
# 查看QC指标
# 查看前五个细胞的筛选指标，要看一下的人的线粒体都是MT但是小鼠的有Mt，也有mt，如果head结果没有线粒体计数，则可以看看是不是pattern的原因
head(seu_obj@meta.data, 5)
##细胞筛选条件可视化

for (i in seq_along(qcparams)){
  print(VlnPlot(object = seu_obj, features = qcparams[i], group.by = "orig.ident", pt.size = 0))
}
for (i in seq_along(qcparams)){
  print(RidgePlot(object = seu_obj, features = qcparams[i], group.by = "orig.ident"))
}

VlnPlot(seu_obj, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"),  group.by = "orig.ident", ncol = 3,raster=FALSE)
######每个特征之间的相关性
plot1 <- FeatureScatter(seu_obj, feature1 = "nCount_RNA", feature2 = "percent.mt",raster=FALSE)
plot2 <- FeatureScatter(seu_obj, feature1 = "nCount_RNA", feature2 = "nFeature_RNA",raster=FALSE)
plot1 + plot2
###数据筛选
seu_obj_f <- subset(seu_obj, subset = nFeature_RNA > nFeature_lower & nFeature_RNA < nFeature_upper & nCount_RNA > nCount_lower & nCount_RNA < nCount_upper & percent.mt < pMT_upper )
####查看一下筛选后细胞数目减少了多少，如果减少的多，可能需要去1.1的代码中调整参数
table(seu_obj$orig.ident)
table(seu_obj_f$orig.ident)
dim(seu_obj_f)
######保存数据
saveRDS(seu_obj_f,"D:/2023.06.单细胞测序.心脾/心脾整体工作/心脾24h_zm1_zs10/0data/心脾合并24h筛选后_30038.rds")
